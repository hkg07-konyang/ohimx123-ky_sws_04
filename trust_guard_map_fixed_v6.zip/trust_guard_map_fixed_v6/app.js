'use strict';
const STORE_PREFIX = 'trust_guard_map_fixed_v6_';
const KEYS = {
  consent: STORE_PREFIX + 'consent', settings: STORE_PREFIX + 'settings', contacts: STORE_PREFIX + 'contacts',
  history: STORE_PREFIX + 'history', incidents: STORE_PREFIX + 'incidents', share: STORE_PREFIX + 'share', datasets: STORE_PREFIX + 'datasets'
};
const DEFAULT_CENTER = { lat: 36.3504, lon: 127.3845, label: '대전광역시청', address: '대전 서구 둔산로 100' };
const PLACES = [
  { name:'건양대학교 메디컬캠퍼스', aliases:['건양대 메디컬','건양대 대전','건양대 병원','건양대학교병원','건양대병원','의료IT공학과'], category:'대학교 · 의료캠퍼스', city:'대전', address:'대전광역시 서구 관저동로 158', lat:36.3042, lon:127.3425, icon:'🏥' },
  { name:'건양대학교 논산창의융합캠퍼스', aliases:['건양대 논산','건양대 논산캠','건양대학교 논산캠퍼스','논산 건양대'], category:'대학교 · 논산캠퍼스', city:'논산', address:'충청남도 논산시 대학로 121', lat:36.1871, lon:127.0987, icon:'🎓' },
  { name:'건양대학교 대전캠퍼스 정문', aliases:['건양대 정문','건양대 메디컬 정문','건양대 입구'], category:'정문 · 만남 장소', city:'대전', address:'대전광역시 서구 관저동로 158 인근', lat:36.3047, lon:127.3417, icon:'📍' },
  { name:'건양대학교병원', aliases:['건양대병원','건양대학교 병원','건양대 병원'], category:'병원', city:'대전', address:'대전광역시 서구 관저동로 158', lat:36.3064, lon:127.3426, icon:'🏥' },
  { name:'대전역', aliases:['대전역 ktx','대전역 지하철','daejeon station'], category:'기차역', city:'대전', address:'대전광역시 동구 중앙로 215', lat:36.3322, lon:127.4346, icon:'🚉' },
  { name:'둔산동', aliases:['둔산','둔산 번화가','갤러리아 둔산'], category:'상권', city:'대전', address:'대전광역시 서구 둔산동', lat:36.3519, lon:127.3785, icon:'🏙️' },
  { name:'유성온천역', aliases:['유성온천','봉명동역'], category:'지하철역', city:'대전', address:'대전광역시 유성구 계룡로', lat:36.3537, lon:127.3415, icon:'🚇' },
  { name:'봉명동', aliases:['유성 봉명동','봉명동 먹자골목'], category:'상권', city:'대전', address:'대전광역시 유성구 봉명동', lat:36.3567, lon:127.3466, icon:'🏙️' },
  { name:'충남대학교', aliases:['충대','충남대','cnu'], category:'대학교', city:'대전', address:'대전광역시 유성구 대학로 99', lat:36.3689, lon:127.3450, icon:'🎓' },
  { name:'KAIST 본원', aliases:['카이스트','kaist','카이스트 대전'], category:'대학교', city:'대전', address:'대전광역시 유성구 대학로 291', lat:36.3722, lon:127.3602, icon:'🎓' },
  { name:'대전광역시청', aliases:['대전시청','시청역'], category:'공공기관', city:'대전', address:'대전광역시 서구 둔산로 100', lat:36.3504, lon:127.3845, icon:'🏛️' },
  { name:'복합터미널', aliases:['대전복합터미널','대전 터미널'], category:'버스터미널', city:'대전', address:'대전광역시 동구 동서대로 1689', lat:36.3502, lon:127.4364, icon:'🚌' }
];
const SAMPLE_FACILITIES = [
  {id:'sample-cctv-001',type:'cctv',label:'CCTV 샘플',lat:36.3509,lon:127.3810,verified:false,source:'시연 샘플'},
  {id:'sample-cctv-002',type:'cctv',label:'CCTV 샘플',lat:36.3488,lon:127.3892,verified:false,source:'시연 샘플'},
  {id:'sample-light-001',type:'light',label:'가로등 샘플',lat:36.3522,lon:127.3750,verified:false,source:'시연 샘플'},
  {id:'sample-light-002',type:'light',label:'가로등 샘플',lat:36.3458,lon:127.3964,verified:false,source:'시연 샘플'},
  {id:'sample-store-001',type:'store',label:'편의점 샘플',lat:36.3501,lon:127.3864,verified:false,source:'시연 샘플'},
  {id:'sample-store-002',type:'store',label:'편의점 샘플',lat:36.3542,lon:127.3702,verified:false,source:'시연 샘플'},
  {id:'sample-police-001',type:'police',label:'안심시설 샘플',lat:36.3491,lon:127.3734,verified:false,source:'시연 샘플'},
  {id:'sample-risk-001',type:'risk',label:'어두운 구간 샘플',lat:36.3474,lon:127.3835,verified:false,source:'시연 샘플'},
  {id:'sample-risk-002',type:'risk',label:'고립 위험 샘플',lat:36.3436,lon:127.4072,verified:false,source:'시연 샘플'}
];
const MODE = {
  sidewalk: { label:'보행자 경로', profile:'local-foot', kmh:4.1, desc:'무료 OSRM 보행 프로필 오류를 피하기 위해 내장 보행 시연 네트워크를 사용합니다. 자동차 경로로 몰래 대체하지 않습니다.' },
  foot: { label:'일반 도보', profile:'local-foot', kmh:4.5, desc:'보행 시연 네트워크 기준입니다. 실제 운영 시 국내 보행자 경로 API로 교체해야 합니다.' },
  car: { label:'자동차/차도', profile:'driving', kmh:38, desc:'자동차 도로 기준입니다. 도보 안내와 명확히 분리합니다.' }
};
const FACILITY_ICON = { cctv:'📹', light:'💡', store:'🏪', police:'🚓', risk:'⚠️' };
const FACILITY_RADIUS = { cctv:90, light:80, store:180, police:500, risk:80 };
let state = {
  tab:'home', map:null, markers:[], lines:[], routes:[], selectedRouteId:null, originText:'', destText:'건양대학교 메디컬캠퍼스',
  originPlace:null, destPlace:PLACES[0], mode:'sidewalk', location:null, accuracy:null, tracking:false, watchId:null, simTimer:null, simIndex:0,
  hold:0, holdTimer:null, routeError:'', focusedSearch:null, highlightedSuggestion:0, chatOpen:false, navStep:0, deferredPrompt:null,
  consent:null, settings:null, contacts:[], history:[], incidents:[], share:null, datasets:null,
  chat:[{role:'ai',text:'저는 외부 AI가 아니라 규칙 기반 안전 어시스턴트입니다. 실제 위급 상황에서는 112 신고와 밝은 장소 이동이 우선입니다.'}]
};
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const esc = v => String(v ?? '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[s]));
const uid = p => `${p}-${Math.random().toString(36).slice(2,9)}-${Date.now().toString(36)}`;
const now = () => new Date().toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
const save = (k,v) => localStorage.setItem(k, JSON.stringify(v));
const load = (k,f) => { try { const raw = localStorage.getItem(k); return raw ? JSON.parse(raw) : f; } catch { return f; } };
const fmtM = m => m < 1000 ? `${Math.round(m)}m` : `${(m/1000).toFixed(1)}km`;
const fmtT = s => `${Math.max(1, Math.round(s/60))}분`;
function meters(a,b){ const R=6371000,dLat=(b.lat-a.lat)*Math.PI/180,dLon=(b.lon-a.lon)*Math.PI/180,la1=a.lat*Math.PI/180,la2=b.lat*Math.PI/180; const x=Math.sin(dLat/2)**2+Math.cos(la1)*Math.cos(la2)*Math.sin(dLon/2)**2; return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x)); }
function isValidCoord(p){ return !!p && Number.isFinite(+p.lat) && Number.isFinite(+p.lon) && +p.lat>=32 && +p.lat<=39.5 && +p.lon>=124 && +p.lon<=132.5; }
function sanitizePoint(p,fallback=DEFAULT_CENTER){ return isValidCoord(p) ? { ...p, lat:+p.lat, lon:+p.lon } : { ...fallback }; }
function clampRoutes(routes){ return (routes||[]).map(r=>({ ...r, geometry:(r.geometry||[]).filter(isValidCoord) })).filter(r=>r.geometry.length>=2); }
function init(){
  state.consent = load(KEYS.consent,{location:false,guardian:false,retention:true,external:false,updatedAt:null});
  state.settings = load(KEYS.settings,{theme:'dark',large:false,retentionDays:30,dataMode:'sample',savePreciseLocation:false,accessibility:true});
  state.contacts = load(KEYS.contacts,[{id:uid('c'),name:'보호자 예시',relation:'가족',phone:'010-1234-5678',consent:false,verified:false}]);
  state.history = load(KEYS.history,[]); state.incidents = load(KEYS.incidents,[]);
  state.share = load(KEYS.share,{enabled:false,token:null,expiresAt:null,lastUpdate:null,serverConnected:false,revoked:false});
  state.datasets = load(KEYS.datasets,{facilities:SAMPLE_FACILITIES,source:'시연 샘플 데이터',importedAt:null,verified:false,mode:'sample'});
  document.documentElement.dataset.theme = state.settings.theme; document.body.classList.toggle('large', !!state.settings.large);
  cleanupRetention(); render(); registerPWA();
}
function render(){
  $('#app').innerHTML = shellHTML();
  $('#mobileNav').innerHTML = mobileNavHTML();
  attachEvents();
  const body = $('#chatBody'); if (body) body.scrollTop = body.scrollHeight;
  setTimeout(()=>{ if(state.tab === 'route') initMap(); }, 20);
}
function setState(p){ state = {...state, ...p}; render(); }
function selectedRoute(){ return state.routes.find(r => r.id === state.selectedRouteId); }
function pageTitle(){ return {home:'서비스 대시보드',route:'경로 검색/안전 분석',live:'실시간 추적',guardian:'보호자 공유',sos:'긴급 SOS',privacy:'보안·동의·데이터',install:'아이폰/갤럭시 앱 설치',audit:'수정 내역'}[state.tab] || 'Trust Guard'; }
function shellHTML(){
  return `<div class="shell"><aside class="side"><div class="row"><div class="logo">S</div><div><div class="tiny muted">Safe Return Home</div><b>TRUST GUARD APP</b></div></div><p class="small muted" style="line-height:1.7">PWA 기반으로 아이폰/갤럭시 홈 화면에 설치 가능하며, 실제 운영에 필요한 서버 기능은 화면에서 분리 표시합니다.</p>${nav('home','⌂','홈')}${nav('route','⌕','경로 검색')}${nav('live','◉','실시간 추적')}${nav('guardian','◈','보호자 공유')}${nav('sos','!','SOS')}${nav('privacy','◌','보안/동의')}${nav('install','▣','앱 설치')}${nav('audit','✓','개선 현황')}<div class="card mt16" style="padding:14px"><div class="small muted">데이터 상태</div><b>${dataStateText()}</b><div class="tiny muted">${esc(state.datasets.source)}</div><button class="secondary full mt12" data-tab="privacy">데이터 설정</button></div></aside><main class="main"><div class="top"><div class="between"><div><div class="tiny muted">iOS/Android installable PWA · honest safety prototype</div><b>${pageTitle()}</b></div><div class="row badges"><span class="badge ${state.consent.location?'safe':'warn'}">위치 ${state.consent.location?'동의':'미동의'}</span><span class="badge ${state.tracking?'safe':'mid'}">GPS ${state.tracking?'추적중':'대기'}</span><span class="badge ${state.share.enabled?'good':'mid'}">공유 ${state.share.enabled?'ON':'OFF'}</span><span class="badge ${state.datasets.verified?'safe':'warn'}">${state.datasets.verified?'공식 데이터':'샘플 데이터'}</span></div></div></div><div class="page">${pageHTML()}</div></main>${chatHTML()}</div>`;
}
function nav(k,i,l){ return `<button class="nav ${state.tab===k?'active':''}" data-tab="${k}"><span class="ico">${i}</span><span>${l}</span></button>`; }
function mobileNavHTML(){ const items=[['home','홈','⌂'],['route','검색','⌕'],['guardian','공유','◈'],['sos','SOS','!'],['install','설치','▣']]; return items.map(([k,l,i])=>`<button class="${state.tab===k?'active':''}" data-tab="${k}">${i}<br>${l}</button>`).join(''); }
function pageHTML(){ return ({home:homeHTML,route:routeHTML,live:liveHTML,guardian:guardianHTML,sos:sosHTML,privacy:privacyHTML,install:installHTML,audit:auditHTML}[state.tab] || homeHTML)(); }
function dataStateText(){ return state.datasets.verified ? '공식/검증 데이터 모드' : '샘플/미검증 데이터 모드'; }
function homeHTML(){
  const r=selectedRoute(), sc=r?scoreRoute(r):null;
  return `<div class="stack"><div class="hero"><span class="badge good">아이폰·갤럭시 설치형 PWA</span><h1 style="font-size:clamp(42px,6vw,74px);line-height:.96;margin:12px 0;letter-spacing:-.07em">검색은 크게,<br>위험은 솔직하게</h1><p class="muted" style="max-width:780px;line-height:1.8">출발지/목적지 검색에 큰 박스형 연관검색어를 넣었고, 샘플 데이터·서버 미연결·SOS 한계를 숨기지 않도록 바꿨습니다. 홈 화면에 추가하면 앱처럼 실행됩니다.</p><div class="grid grid3"><button data-tab="route">경로 검색 시작</button><button data-tab="install" class="secondary">아이폰/갤럭시 설치법</button><button data-tab="sos" class="danger">SOS 화면</button></div></div><div class="grid grid4"><div class="stat"><span class="small muted">현재 위험도</span><strong>${sc?sc.risk+'점':'-'}</strong><span class="small muted">${sc?sc.label:'경로 계산 필요'}</span></div><div class="stat"><span class="small muted">데이터 신뢰도</span><strong>${state.datasets.verified?'공식':'샘플'}</strong><span class="small muted">${esc(state.datasets.source)}</span></div><div class="stat"><span class="small muted">보호자 공유</span><strong>${state.share.enabled?'ON':'OFF'}</strong><span class="small muted">실서버: ${state.share.serverConnected?'연결':'미연결'}</span></div><div class="stat"><span class="small muted">앱 설치 상태</span><strong>${isStandalone()?'설치됨':'웹/PWA'}</strong><span class="small muted">iOS·Android 홈 화면 실행 가능</span></div></div><div class="two"><div class="card"><h2 class="m0">빠른 목적지</h2><p class="muted">샘플 장소입니다. 실제 서비스에서는 집 주소를 화면에 직접 노출하지 않고 별칭만 보여주는 방식이 안전합니다.</p><div class="grid grid2">${PLACES.slice(0,8).map(p=>`<button class="secondary" data-place-dest="${p.name}"><b>${p.icon} ${esc(p.name)}</b><br><span class="small muted">${esc(p.category)} · ${esc(p.city)}</span></button>`).join('')}</div></div><div class="card"><h2 class="m0">귀가 전 체크</h2>${check('위치정보 동의',state.consent.location)}${check('보호자 본인 동의 확인',state.contacts.some(c=>c.consent&&c.verified))}${check('경로 선택',!!r)}${check('공식 데이터 연결',state.datasets.verified)}<div class="notice mt12"><b>발표 방어 문장</b><br>현재는 설치형 PWA 프로토타입입니다. 실제 운영은 서버 인증, DB, 공식 공공데이터 API, 푸시/SMS 발송, 네이티브 백그라운드 GPS가 추가되어야 합니다.</div></div></div></div>`;
}
function check(text,on){ return `<div class="mini between"><span>${text}</span><b class="${on?'safeText':'midText'}">${on?'완료':'필요'}</b></div>`; }
function routeHTML(){
  const r=selectedRoute();
  return `<div class="route-layout"><div class="card"><h2 class="m0">출발지 · 목적지 검색</h2><p class="muted">검색창에 “건양대”처럼 입력하면 큰 박스형 연관검색어가 뜹니다. 방향키/터치 모두 지원합니다.</p><div class="grid grid2"><div class="search-wrap"><label>출발지</label><input id="originInput" autocomplete="off" value="${esc(state.originText)}" placeholder="비우면 현재 위치 또는 대전광역시청" aria-label="출발지 검색"><div id="originSuggest"></div></div><div class="search-wrap"><label>목적지</label><input id="destInput" autocomplete="off" value="${esc(state.destText)}" placeholder="예: 건양대, 대전역, 둔산동" aria-label="목적지 검색"><div id="destSuggest"></div></div></div><div class="search-hint mt12"><span class="chip" data-query="건양대">건양대</span><span class="chip" data-query="건양대학교">건양대학교</span><span class="chip" data-query="대전역">대전역</span><span class="chip" data-query="둔산동">둔산동</span></div><div class="grid grid3 mt16"><div><label>이동 기준</label><select id="modeSelect">${Object.entries(MODE).map(([k,m])=>`<option value="${k}" ${state.mode===k?'selected':''}>${m.label}</option>`).join('')}</select></div><button id="calcRoute" style="align-self:end">안전 경로 계산</button><button id="getGPS" class="secondary" style="align-self:end">현재 위치 사용</button></div><div class="info mt12"><b>${MODE[state.mode].label}</b><br>${MODE[state.mode].desc} · 자동차 경로로 몰래 대체하지 않습니다.</div>${state.routeError?`<div class="dangerbox mt12">${esc(state.routeError)}</div>`:''}<div class="mt16"><div id="map"></div></div>${state.routes.length?`<div class="grid grid3 mt16">${state.routes.map(routeCard).join('')}</div>`:''}</div><div class="stack"><div class="card"><h2 class="m0">선택 경로 분석</h2>${r?routeDetail(r):'<div class="mini mt12">경로를 계산하면 안전점수, 데이터 신뢰도, 시설 반경, 비상 안내 여부가 표시됩니다.</div>'}</div><div class="card"><h3 class="m0">지도 범례</h3>${legendHTML()}</div></div></div>`;
}
function routeCard(r){ const sc=scoreRoute(r); return `<div class="route-card ${state.selectedRouteId===r.id?'active':''}" data-route="${r.id}"><div class="between"><div><b>${esc(r.title)}</b><div class="small muted">${r.distanceText} · ${r.durationText}</div></div><span class="badge ${r.emergency?'warn':scoreClass(sc.score)}">${r.emergency?'비상 안내':sc.risk+'점'}</span></div><div class="tiny muted mt8">${esc(r.source)} · CCTV ${r.evidence.cctv} · 가로등 ${r.evidence.light} · 위험 ${r.evidence.risk}</div></div>`; }
function routeDetail(r){
  const sc=scoreRoute(r);
  return `<div class="between mt12"><div><b style="font-size:18px">${esc(r.title)}</b><div class="small muted">${r.distanceText} · ${r.durationText} · ${MODE[r.mode].label}</div></div><span class="badge ${r.emergency?'warn':scoreClass(sc.score)}">${r.emergency?'실제 길 아님':'위험도 '+sc.risk+'점'}</span></div><div class="mt12"><div class="between"><span class="small">안전 신뢰 점수</span><b>${sc.score}/100</b></div><div class="progress"><span style="width:${sc.score}%"></span></div></div><div class="grid grid2 mt12"><div class="mini"><b>안전 근거</b><br>CCTV ${r.evidence.cctv} · 가로등 ${r.evidence.light} · 편의점 ${r.evidence.store} · 경찰/안심시설 ${r.evidence.police}</div><div class="mini"><b>위험/제한</b><br>위험구간 ${r.evidence.risk} · GPS ${state.accuracy?Math.round(state.accuracy)+'m':'미측정'} · ${state.datasets.verified?'공식 데이터':'샘플 데이터'}</div></div><div class="info mt12"><b>점수 공식</b><br>기본 55점 + 시설별 가중치 - 위험/미검증/GPS오차 패널티. 공식 데이터가 아니면 실제 안전 판단으로 사용하지 않습니다.</div>${r.emergency?'<div class="dangerbox mt12"><b>주의</b><br>이 경로는 API 실패 시 만든 직선 안내입니다. 실제 길 안내로 사용하면 안 됩니다.</div>':''}<div class="grid grid2 mt12"><button id="beginTrip" class="safe" ${r.emergency?'disabled':''}>귀가 시작</button><button id="shareRoute" class="secondary">보호자 공유 설정</button></div><h3>단계별 안내</h3>${r.steps.map((s,i)=>`<div class="step ${state.navStep===i?'active':''}"><b>${i+1}. ${esc(s.instruction)}</b><br><span class="small muted">${fmtM(s.distance)} · ${fmtT(s.duration)}</span></div>`).join('')}`;
}
function legendHTML(){ return `<div class="grid grid2"><div class="mini">📹 CCTV 반경 90m</div><div class="mini">💡 가로등 반경 80m</div><div class="mini">🏪 편의점 반경 180m</div><div class="mini">🚓 경찰/안심시설 반경 500m</div><div class="mini">⚠️ 위험구간 반경 80m</div><div class="mini">🔵 현재 위치</div></div><div class="notice mt12">시설별 반경을 다르게 적용했습니다. 샘플 데이터는 항상 샘플로 표시됩니다.</div>`; }
function liveHTML(){ const r=selectedRoute(), dev=deviation(); return `<div class="stack"><div class="grid grid4"><div class="stat"><span class="small muted">GPS 상태</span><strong>${state.tracking?'추적중':'대기'}</strong><span class="small muted">${state.location?state.location.lat.toFixed(5)+', '+state.location.lon.toFixed(5):'위치 없음'}</span></div><div class="stat"><span class="small muted">정확도</span><strong>${state.accuracy?Math.round(state.accuracy)+'m':'-'}</strong><span class="small muted">80m 초과 시 보류</span></div><div class="stat"><span class="small muted">경로 이탈</span><strong>${dev?Math.round(dev)+'m':'-'}</strong><span class="small muted">선택 경로 기준</span></div><div class="stat"><span class="small muted">마지막 공유</span><strong>${state.share.lastUpdate||'-'}</strong><span class="small muted">서버 미연결 시 로컬 표시</span></div></div><div class="two"><div class="card"><h2>추적 제어</h2><div class="grid grid3"><button id="startWatch">시작</button><button id="stopWatch" class="secondary">중지</button><button id="simGPS" class="secondary">시연 이동</button></div><div class="notice mt12">PWA의 브라우저 위치 추적은 백그라운드에서 제한될 수 있습니다. 실제 앱 운영은 네이티브 백그라운드 위치 권한이 필요합니다.</div></div><div class="card"><h2>이상상황 감지</h2>${anomalyHTML()}</div></div></div>`; }
function anomalyHTML(){ const r=selectedRoute(), dev=deviation(), items=[]; if(!state.tracking)items.push(['GPS 추적 꺼짐','귀가 중에는 추적을 켜야 이탈 판단이 가능합니다.','mid']); if(state.accuracy&&state.accuracy>80)items.push(['GPS 오차 큼','위치 정확도가 낮아 이탈 판단을 보류해야 합니다.','warn']); if(dev&&dev>80)items.push(['경로 이탈 가능','선택 경로에서 80m 이상 벗어났습니다. 보호자 알림 후보입니다.','warn']); if(!state.share.enabled)items.push(['공유 꺼짐','보호자 공유가 꺼져 있습니다.','mid']); if(!r)items.push(['선택 경로 없음','이탈 감지를 하려면 경로 선택이 필요합니다.','mid']); if(!items.length)items.push(['정상 모니터링','현재 큰 이상 신호가 없습니다.','safe']); return items.map(x=>`<div class="mini between"><div><b>${x[0]}</b><br><span class="small muted">${x[1]}</span></div><span class="badge ${x[2]}">${x[2]==='warn'?'주의':'확인'}</span></div>`).join(''); }
function guardianHTML(){ const link=makeShareLink(false); return `<div class="stack"><div class="two"><div class="card"><h2>보호자 공유</h2><div class="notice"><b>중요</b><br>현재 파일은 서버가 없기 때문에 진짜 크로스디바이스 실시간 공유가 아닙니다. 앱 전환용 구조와 UI만 구현했습니다.</div><div class="mini between mt12"><div><b>공유 상태</b><br><span class="small muted">위치 동의 + 보호자 동의/확인 필요</span></div><input id="shareToggle" type="checkbox" ${state.share.enabled?'checked':''} style="width:24px;height:24px"></div><div class="info mt12"><b>공유 링크</b><br><span class="small mono">${esc(link)}</span><br><span class="tiny muted">만료: ${state.share.expiresAt?new Date(state.share.expiresAt).toLocaleString('ko-KR'):'없음'} · 서버: ${state.share.serverConnected?'연결':'미연결'}</span></div><div class="grid grid3 mt12"><button id="copyShare" class="secondary">복사</button><button id="regenShare" class="secondary">재발급</button><button id="revokeShare" class="danger">철회</button></div></div><div class="card"><h2>보호자 화면 미리보기</h2>${guardianPreview()}</div></div><div class="card"><div class="between"><h2 class="m0">보호자 연락처</h2><span class="badge warn">본인 확인 필요</span></div><div class="grid grid2 mt12">${state.contacts.map(contactCard).join('')}</div><form id="contactForm" class="grid grid4 mt16"><input id="cName" placeholder="이름"><input id="cRel" placeholder="관계"><input id="cPhone" placeholder="전화번호"><button>추가</button></form></div></div>`; }
function contactCard(c){ return `<div class="mini"><div class="between"><div><b>${esc(c.name)}</b><br><span class="small muted">${esc(c.relation)} · ${esc(c.phone)}</span></div><button class="secondary" data-del-contact="${c.id}">삭제</button></div><label class="row small mt12"><input type="checkbox" data-contact-consent="${c.id}" ${c.consent?'checked':''} style="width:18px;height:18px"> 위치 공유 동의 받음</label><label class="row small mt8"><input type="checkbox" data-contact-verified="${c.id}" ${c.verified?'checked':''} style="width:18px;height:18px"> 보호자 본인이 확인함</label></div>`; }
function guardianPreview(){ const r=selectedRoute(); return `<div class="grid grid2"><div class="mini"><b>상태</b><br>${state.tracking?'귀가 중':'대기 중'}</div><div class="mini"><b>갱신</b><br>${state.share.lastUpdate||'-'}</div><div class="mini"><b>위치</b><br>${state.location?maskLocation(state.location):'위치 없음'}</div><div class="mini"><b>경로</b><br>${r?esc(r.title):'미선택'}</div></div><div class="dangerbox mt12">실제 서비스는 보호자 로그인, 접속 로그, 서버 저장소, 푸시 알림이 필요합니다.</div>`; }
function sosHTML(){ return `<div class="two"><div class="card"><h2>SOS 긴급 대응</h2><div class="dangerbox"><b>실제 위급 상황에서는 112 신고가 우선입니다.</b><br>오작동 방지를 위해 3초 이상 길게 눌러야 SOS 로그가 생성됩니다.</div><button id="sosHold" class="hold" style="--p:${state.hold}%"><span>SOS<br><small>${state.hold?Math.round(state.hold)+'%':'3초'}</small></span></button><div class="grid grid3"><a href="tel:112"><button type="button" class="danger full">112 전화</button></a><button id="copySOS" class="secondary">문구 복사</button><button id="testSOS" class="warn">모의 알림</button></div><label class="mt12">긴급 메시지</label><textarea id="sosMsg">${esc(sosMessage())}</textarea></div><div class="card"><h2>보호자 문자</h2><div class="grid">${state.contacts.filter(c=>c.consent&&c.verified).map(c=>`<a href="sms:${esc(c.phone)}?body=${encodeURIComponent(sosMessage())}"><button type="button" class="secondary full">${esc(c.name)}에게 문자 열기</button></a>`).join('')||'<div class="notice">검증된 보호자가 없습니다. 보호자 공유 탭에서 동의와 확인을 체크하세요.</div>'}</div><h3>긴급 로그</h3><div class="grid">${state.incidents.slice(0,6).map(i=>`<div class="mini"><b>${esc(i.type)}</b><br><span class="small muted">${esc(i.time)} · ${esc(i.message)}</span></div>`).join('')||'<div class="mini">아직 긴급 로그가 없습니다.</div>'}</div></div></div>`; }
function privacyHTML(){ return `<div class="stack"><div class="card"><h2>동의 관리</h2><div class="grid grid2"><label class="mini"><input id="consLoc" type="checkbox" ${state.consent.location?'checked':''}> 위치정보 수집 동의<br><span class="small muted">경로 탐색, 이탈 감지, SOS 위치 문구에 사용</span></label><label class="mini"><input id="consGuard" type="checkbox" ${state.consent.guardian?'checked':''}> 보호자 공유 동의<br><span class="small muted">검증된 보호자에게만 위치 상태 공유</span></label><label class="mini"><input id="consRet" type="checkbox" ${state.consent.retention?'checked':''}> 귀가 기록 보관 동의<br><span class="small muted">보관기간 초과 기록은 앱 실행 시 자동 정리</span></label><label class="mini"><input id="consExt" type="checkbox" ${state.consent.external?'checked':''}> 외부 서버/AI 전송 동의<br><span class="small muted">현재 버전은 외부 AI 전송 없음</span></label></div><div class="grid grid3 mt16"><button id="saveConsent">동의 저장</button><button id="exportData" class="secondary">데이터 내보내기</button><button id="deleteAll" class="danger">전체 삭제</button></div></div><div class="card"><h2>보안 설정</h2><div class="grid grid3"><div><label>기록 보관 기간</label><select id="retention"><option value="7" ${state.settings.retentionDays==7?'selected':''}>7일</option><option value="30" ${state.settings.retentionDays==30?'selected':''}>30일</option><option value="90" ${state.settings.retentionDays==90?'selected':''}>90일</option></select></div><label class="mini"><input id="largeText" type="checkbox" ${state.settings.large?'checked':''}> 큰 글자 모드</label><label class="mini"><input id="themeToggle" type="checkbox" ${state.settings.theme==='light'?'checked':''}> 라이트 모드</label></div><div class="notice mt12">정확한 집 위치 저장은 기본 비활성화입니다. 기록에는 정밀 위치 대신 경로 제목·시간·위험도 중심으로 저장합니다.</div></div><div class="card"><h2>공공데이터 연결 준비</h2><div class="grid grid2"><div class="mini"><b>현재 데이터</b><br>${dataStateText()} · ${esc(state.datasets.source)}<br><span class="small muted">시설 ${state.datasets.facilities.length}개</span></div><div class="mini"><b>필수 실제 데이터</b><br>CCTV, 가로등, 편의점, 경찰서, 안심시설, 위험 신고, 유동인구, 보행로</div></div><div class="mt12"><label>시설 JSON 가져오기</label><input id="dataImport" type="file" accept="application/json"></div><div class="info mt12">JSON 예시: [{"type":"cctv","label":"CCTV","lat":36.35,"lon":127.38,"source":"공공데이터포털"}]</div></div></div>`; }
function installHTML(){ return `<div class="stack"><div class="hero"><span class="badge good">iPhone · Galaxy 지원</span><h1 style="font-size:clamp(38px,5vw,64px);line-height:1;margin:12px 0">앱처럼 설치하는 버전</h1><p class="muted" style="line-height:1.8;max-width:760px">이 파일은 PWA라서 서버에 올리면 아이폰 Safari와 갤럭시 Chrome/Samsung Internet에서 홈 화면 앱처럼 실행할 수 있습니다. 앱스토어 등록 전 시연용으로 가장 빠른 방식입니다.</p><div class="grid grid3"><button id="installPrompt">갤럭시 설치 버튼</button><button id="copyInstall" class="secondary">설치 안내 복사</button><button data-tab="route" class="secondary">경로 검색 보기</button></div></div><div class="grid grid2"><div class="card"><h2>아이폰 설치</h2><div class="install-card">1. Safari로 사이트 열기<br>2. 하단 공유 버튼 누르기<br>3. <b>홈 화면에 추가</b> 선택<br>4. Trust Guard 아이콘 실행</div><div class="notice mt12">iOS는 브라우저 정책상 설치 버튼을 앱 안에서 직접 띄우기 어렵습니다. Safari의 “홈 화면에 추가”를 사용해야 합니다.</div></div><div class="card"><h2>갤럭시 설치</h2><div class="install-card">1. Chrome 또는 Samsung Internet으로 사이트 열기<br>2. 주소창/메뉴의 <b>앱 설치</b> 또는 <b>홈 화면에 추가</b> 선택<br>3. Trust Guard 실행</div><div class="ok mt12">Android Chrome에서는 조건이 맞으면 위의 “갤럭시 설치 버튼”으로 설치 창이 뜰 수 있습니다.</div></div></div><div class="card"><h2>네이티브 앱 전환</h2><p class="muted">압축파일에는 Capacitor 설정 파일도 넣었습니다. 개발 환경에서 <span class="mono">npm install</span> 후 iOS/Android 프로젝트로 감쌀 수 있습니다. 단, 실제 배포는 Apple/Google 개발자 계정과 서명 과정이 필요합니다.</p></div></div>`; }
function auditHTML(){ const rows=[['아이폰/갤럭시 앱 사용','PWA manifest, service worker, 아이콘, 설치 안내, Capacitor 설정 추가'],['연관검색어 UI 부족','출발지/목적지 입력 시 큰 박스형 추천 카드 표시. “건양대” → 논산캠퍼스/메디컬캠퍼스 등 노출'],['샘플 데이터 오해','샘플/공식 데이터 배지 분리, 시설별 출처·검증 상태 표시'],['보호자 공유 과장','서버 미연결 표시, 동의/본인확인 게이트, 만료 토큰/철회 UI 추가'],['인도 우선 과장','“인도 보장” 대신 “보행자 경로”로 수정. 자동차 경로 fallback 금지'],['시설 반경 과대','시설 종류별 반경 분리: CCTV 90m, 가로등 80m, 편의점 180m, 경찰 500m'],['SOS 자동 신고 오해','112 전화/문자 열기/모의 알림을 분리하고 자동 신고가 아님을 명시'],['개인정보 저장 위험','정밀 위치 저장 기본 비활성, 내보내기 마스킹, 보관기간 자동정리, 전체 삭제 추가'],['AI 과장','규칙 기반 안전 어시스턴트로 명칭 변경'] ]; return `<div class="card"><h2>수정 내역</h2><table><thead><tr><th>문제</th><th>수정 내용</th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>${r[0]}</b></td><td>${r[1]}</td></tr>`).join('')}</tbody></table><div class="info mt16"><b>교수님 방어 핵심</b><br>이 버전은 완성 서비스가 아니라 iOS/Android 설치형 PWA 프로토타입입니다. 실제 운영 전환 시 서버, 공식 API, 네이티브 백그라운드 위치, 푸시/SMS가 필요합니다.</div></div>`; }
function chatHTML(){ return `<button class="chatFab" id="chatBtn">상담</button><div class="chat card ${state.chatOpen?'open':''}"><div class="chatHead"><b>규칙 기반 안전 어시스턴트</b><br><span class="small">외부 AI 전송 없음</span></div><div class="chatBody" id="chatBody">${state.chat.map(m=>`<div class="msg ${m.role==='me'?'me':'ai'}">${esc(m.text)}</div>`).join('')}</div><div class="quick"><button data-q="위험해">위험해</button><button data-q="공유 켜줘">공유 켜줘</button><button data-q="건양대 검색">건양대 검색</button></div><form class="chatForm" id="chatForm"><input id="chatInput" placeholder="상황을 입력하세요"><button>전송</button></form></div>`; }
function attachEvents(){
  $$('[data-tab]').forEach(el=>el.onclick=()=>setState({tab:el.dataset.tab}));
  $$('[data-place-dest]').forEach(el=>el.onclick=()=>{ const p=findPlaceByName(el.dataset.placeDest); state.destPlace=p; state.destText=p.name; setState({tab:'route'}); });
  $('#originInput') && setupSearchInput('origin'); $('#destInput') && setupSearchInput('dest');
  $$('.chip').forEach(chip=>chip.onclick=()=>{ state.destText=chip.dataset.query; state.focusedSearch='dest'; render(); setTimeout(()=>$('#destInput')?.focus(),30); });
  $('#modeSelect') && ($('#modeSelect').onchange=e=>{state.mode=e.target.value; render();});
  $('#calcRoute') && ($('#calcRoute').onclick=calcRoutes); $('#getGPS') && ($('#getGPS').onclick=requestLocation);
  $('#startWatch') && ($('#startWatch').onclick=startWatch); $('#stopWatch') && ($('#stopWatch').onclick=stopWatch); $('#simGPS') && ($('#simGPS').onclick=toggleSim);
  $$('[data-route]').forEach(el=>el.onclick=()=>setState({selectedRouteId:el.dataset.route}));
  $('#beginTrip') && ($('#beginTrip').onclick=beginTrip); $('#shareRoute') && ($('#shareRoute').onclick=()=>setState({tab:'guardian'}));
  $('#shareToggle') && ($('#shareToggle').onchange=e=>toggleShare(e.target.checked)); $('#copyShare') && ($('#copyShare').onclick=()=>copyText(makeShareLink(true),'공유 링크를 복사했습니다.'));
  $('#regenShare') && ($('#regenShare').onclick=()=>{ state.share.token=null; makeShareLink(true); save(KEYS.share,state.share); render(); });
  $('#revokeShare') && ($('#revokeShare').onclick=()=>{ state.share={enabled:false,token:null,expiresAt:null,lastUpdate:null,serverConnected:false,revoked:true}; save(KEYS.share,state.share); render(); });
  $('#contactForm') && ($('#contactForm').onsubmit=e=>{e.preventDefault(); const n=$('#cName').value.trim(),r=$('#cRel').value.trim(),p=$('#cPhone').value.trim(); if(!n||!p)return alert('이름과 전화번호를 입력하세요.'); state.contacts.push({id:uid('c'),name:n,relation:r||'보호자',phone:p,consent:false,verified:false}); save(KEYS.contacts,state.contacts); render();});
  $$('[data-del-contact]').forEach(b=>b.onclick=()=>{ state.contacts=state.contacts.filter(c=>c.id!==b.dataset.delContact); save(KEYS.contacts,state.contacts); render(); });
  $$('[data-contact-consent]').forEach(ch=>ch.onchange=e=>{ const c=state.contacts.find(x=>x.id===e.target.dataset.contactConsent); if(c)c.consent=e.target.checked; save(KEYS.contacts,state.contacts); render(); });
  $$('[data-contact-verified]').forEach(ch=>ch.onchange=e=>{ const c=state.contacts.find(x=>x.id===e.target.dataset.contactVerified); if(c)c.verified=e.target.checked; save(KEYS.contacts,state.contacts); render(); });
  $('#sosHold') && setupHold(); $('#copySOS') && ($('#copySOS').onclick=()=>copyText(sosMessage(),'SOS 문구를 복사했습니다.')); $('#testSOS') && ($('#testSOS').onclick=()=>triggerSOS('모의 알림'));
  $('#saveConsent') && ($('#saveConsent').onclick=saveConsent); $('#exportData') && ($('#exportData').onclick=exportData); $('#deleteAll') && ($('#deleteAll').onclick=deleteAll);
  $('#retention') && ($('#retention').onchange=e=>{state.settings.retentionDays=Number(e.target.value); save(KEYS.settings,state.settings); cleanupRetention(); render();});
  $('#largeText') && ($('#largeText').onchange=e=>{state.settings.large=e.target.checked; save(KEYS.settings,state.settings); document.body.classList.toggle('large', e.target.checked); render();});
  $('#themeToggle') && ($('#themeToggle').onchange=e=>{state.settings.theme=e.target.checked?'light':'dark'; save(KEYS.settings,state.settings); document.documentElement.dataset.theme=state.settings.theme; render();});
  $('#dataImport') && ($('#dataImport').onchange=importDataset); $('#installPrompt') && ($('#installPrompt').onclick=installApp); $('#copyInstall') && ($('#copyInstall').onclick=()=>copyText('아이폰: Safari → 공유 → 홈 화면에 추가\n갤럭시: Chrome/Samsung Internet → 앱 설치 또는 홈 화면에 추가', '설치 안내를 복사했습니다.'));
  $('#chatBtn') && ($('#chatBtn').onclick=()=>setState({chatOpen:!state.chatOpen})); $$('[data-q]').forEach(b=>b.onclick=()=>askChat(b.dataset.q)); $('#chatForm') && ($('#chatForm').onsubmit=e=>{e.preventDefault(); const v=$('#chatInput').value.trim(); if(v) askChat(v);});
}
function setupSearchInput(kind){
  const input = kind === 'origin' ? $('#originInput') : $('#destInput');
  const holder = kind === 'origin' ? $('#originSuggest') : $('#destSuggest');
  const textKey = kind === 'origin' ? 'originText' : 'destText';
  input.onfocus = () => { state.focusedSearch=kind; renderSuggestions(kind); };
  input.oninput = e => { state[textKey]=e.target.value; state.focusedSearch=kind; state.highlightedSuggestion=0; if(kind==='origin')state.originPlace=null; else state.destPlace=null; renderSuggestions(kind); };
  input.onkeydown = e => handleSuggestKey(e,kind);
  setTimeout(()=>{ if(state.focusedSearch===kind) renderSuggestions(kind); },0);
  document.addEventListener('click', e=>{ if(!input.contains(e.target) && !holder.contains(e.target) && state.focusedSearch===kind){ state.focusedSearch=null; renderSuggestions(kind); } }, {once:true});
}
function handleSuggestKey(e,kind){ const q=kind==='origin'?state.originText:state.destText; const list=searchPlaces(q); if(!list.length)return; if(e.key==='ArrowDown'){e.preventDefault();state.highlightedSuggestion=(state.highlightedSuggestion+1)%list.length;renderSuggestions(kind);} if(e.key==='ArrowUp'){e.preventDefault();state.highlightedSuggestion=(state.highlightedSuggestion-1+list.length)%list.length;renderSuggestions(kind);} if(e.key==='Enter'){e.preventDefault();selectSuggestion(kind,list[state.highlightedSuggestion]||list[0]);} if(e.key==='Escape'){state.focusedSearch=null;renderSuggestions(kind);} }
function renderSuggestions(kind){
  const holder = kind === 'origin' ? $('#originSuggest') : $('#destSuggest');
  if(!holder) return;
  if(state.focusedSearch !== kind){ holder.innerHTML = ''; return; }
  const q = kind === 'origin' ? state.originText : state.destText;
  const list = searchPlaces(q);
  const empty = '<div class="suggest-empty">검색 결과가 없어요.<br>정확한 주소를 입력하면 외부 주소검색으로 시도합니다.</div>';
  holder.innerHTML = `<div class="suggest-panel" role="listbox">${list.length ? list.map((p,i)=>suggestCard(p,kind,i)).join('') : empty}</div>`;
  $$(`[data-suggest-${kind}]`).forEach(el => {
    el.onclick = () => selectSuggestion(kind, list[Number(el.getAttribute(`data-suggest-${kind}`))]);
  });
}
function suggestCard(p,kind,i){ return `<div class="suggest-card ${i===state.highlightedSuggestion?'active':''}" data-suggest-${kind}="${i}" role="option"><div class="suggest-icon">${p.icon||'📍'}</div><div><div class="suggest-title">${esc(p.name)}</div><div class="suggest-addr">${esc(p.address)}</div><div class="suggest-meta"><span class="badge good">${esc(p.category)}</span><span class="badge mid">${esc(p.city)}</span></div></div><div class="nowrap"><span class="badge safe">선택</span></div></div>`; }
function capitalize(s){return s.charAt(0).toUpperCase()+s.slice(1);}
function selectSuggestion(kind,p){ if(!p)return; if(kind==='origin'){ state.originPlace=p; state.originText=p.name; } else { state.destPlace=p; state.destText=p.name; } state.focusedSearch=null; state.highlightedSuggestion=0; render(); }
function normalize(s){return String(s||'').toLowerCase().replace(/\s+/g,'').replace(/[대학교]/g,'');}
function searchPlaces(q){ const raw=String(q||'').trim(); const norm=normalize(raw); let list=PLACES.map(p=>{ const hay=[p.name,p.category,p.city,p.address,...(p.aliases||[])].join(' '); const hnorm=normalize(hay); let score=0; if(!raw) score=1; else { if(normalize(p.name).includes(norm)) score+=100; if((p.aliases||[]).some(a=>normalize(a).includes(norm))) score+=80; if(hnorm.includes(norm)) score+=45; if(norm && normalize(p.name).startsWith(norm)) score+=25; if(raw.includes('건양') && p.name.includes('건양')) score+=100; } return {...p,score}; }).filter(p=>p.score>0).sort((a,b)=>b.score-a.score); return list.slice(0,7); }
function findPlaceByName(name){return PLACES.find(p=>p.name===name)||PLACES[0];}
async function geocode(text,place){
  if(place && isValidCoord(place)) return sanitizePoint({lat:place.lat,lon:place.lon,label:place.name,address:place.address});
  const q=String(text||'').trim();
  const local=searchPlaces(q)[0];
  if(local && q) return sanitizePoint({lat:local.lat,lon:local.lon,label:local.name,address:local.address});
  if(!q) throw new Error('검색어가 비어 있습니다. 큰 박스형 연관검색어에서 장소를 선택하거나 주소를 입력하세요.');
  try{
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),5500);
    const url='https://nominatim.openstreetmap.org/search?format=json&limit=3&countrycodes=kr&q='+encodeURIComponent(q);
    const res=await fetch(url,{signal:ctrl.signal});
    clearTimeout(timer);
    if(!res.ok) throw new Error('주소검색 서버 응답 오류');
    const data=await res.json();
    const item=(data||[]).find(x=>Number.isFinite(+x.lat)&&Number.isFinite(+x.lon));
    if(item) return sanitizePoint({lat:+item.lat,lon:+item.lon,label:item.display_name,address:item.display_name});
  }catch(e){
    console.warn('[geocode fallback]', e);
  }
  throw new Error('주소를 찾지 못했습니다: '+q+' · 예: 건양대, 대전역처럼 입력한 뒤 큰 카드에서 선택해 주세요.');
}
async function calcRoutes(){
  state.routeError=''; state.routes=[]; state.selectedRouteId=null; render();
  try {
    let start;
    if(state.originPlace || state.originText.trim()) start=await geocode(state.originText,state.originPlace);
    else if(state.location) start=sanitizePoint(state.location);
    else start=sanitizePoint(DEFAULT_CENTER);
    const end=await geocode(state.destText,state.destPlace);
    let routes=[];
    if(state.mode==='car'){
      routes=await osrmRoutes(start,end,state.mode);
      if(!routes.length) state.routeError='자동차 경로 API가 실패했습니다. 시연용 대체 경로를 표시합니다.';
    } else {
      routes=localWalkingRoutes(start,end,state.mode);
      state.routeError='보행자 경로는 외부 무료 API 오류를 줄이기 위해 내장 시연 네트워크로 표시합니다. 실제 서비스는 국내 보행자 경로 API로 교체해야 합니다.';
    }
    if(!routes.length){
      routes=[emergencyRoute(start,end)];
      state.routeError='경로 계산이 실패하여 비상 직선 안내만 표시합니다. 실제 길 안내로 사용하면 안 됩니다.';
    }
    state.routes=clampRoutes(routes);
    state.selectedRouteId=state.routes[0]?.id || null;
    render();
  } catch(e){
    state.routeError=e.message || '경로 계산 중 오류가 발생했습니다.';
    render();
  }
}
async function osrmRoutes(start,end,mode){
  const profile=MODE[mode].profile;
  if(profile!=='driving') return [];
  const url=`https://router.project-osrm.org/route/v1/driving/${start.lon},${start.lat};${end.lon},${end.lat}?overview=full&geometries=geojson&steps=true&alternatives=true`;
  try {
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),7000);
    const res=await fetch(url,{signal:ctrl.signal});
    clearTimeout(timer);
    if(!res.ok) return [];
    const json=await res.json();
    if(json.code!=='Ok' || !Array.isArray(json.routes)) return [];
    return json.routes.slice(0,3).map((r,i)=>makeRoute(
      (r.geometry?.coordinates||[]).map(c=>({lat:+c[1],lon:+c[0]})).filter(isValidCoord),
      r.distance, r.duration, mode, `자동차 후보 ${i+1}`, false, 'OSRM driving', r.legs?.[0]?.steps||[]
    )).filter(r=>r.geometry.length>=2);
  } catch(e){
    console.warn('[osrm fallback]', e);
    return [];
  }
}
function localWalkingRoutes(start,end,mode){
  start=sanitizePoint(start); end=sanitizePoint(end);
  const variants=[
    {title:'보행 시연 경로 A · 큰길 우선',bend:0.0045,source:'내장 보행 시연 네트워크'},
    {title:'보행 시연 경로 B · 안전시설 우선',bend:-0.0055,source:'내장 보행 시연 네트워크'},
    {title:'보행 시연 경로 C · 우회 후보',bend:0.0025,source:'내장 보행 시연 네트워크'}
  ];
  return variants.map(v=>{
    const geom=curvedPath(start,end,v.bend);
    const dist=pathDistance(geom);
    return makeRoute(geom,dist,dist/(MODE[mode].kmh*1000/3600),mode,v.title,false,v.source,[]);
  });
}
function curvedPath(start,end,bend){
  const midLat=(start.lat+end.lat)/2, midLon=(start.lon+end.lon)/2;
  const dLat=end.lat-start.lat, dLon=end.lon-start.lon;
  const norm=Math.sqrt(dLat*dLat+dLon*dLon) || 1;
  const offLat=(-dLon/norm)*bend, offLon=(dLat/norm)*bend;
  const q1={lat:start.lat+dLat*0.28+offLat*0.65, lon:start.lon+dLon*0.28+offLon*0.65};
  const q2={lat:midLat+offLat, lon:midLon+offLon};
  const q3={lat:start.lat+dLat*0.72+offLat*0.55, lon:start.lon+dLon*0.72+offLon*0.55};
  return [start,q1,q2,q3,end].filter(isValidCoord);
}
function pathDistance(geom){ let d=0; for(let i=1;i<geom.length;i++) d+=meters(geom[i-1],geom[i]); return d; }
function makeRoute(geom,distance,duration,mode,title,emergency,source,stepsRaw){ geom=(geom||[]).filter(isValidCoord); distance=Number.isFinite(distance)?distance:pathDistance(geom); duration=Number.isFinite(duration)?duration:distance/(MODE[mode].kmh*1000/3600); const facilities=facilitiesNear(geom); const evidence=countEvidence(facilities); const steps=stepsRaw&&stepsRaw.length?stepsRaw.slice(0,8).map(s=>({instruction:stepText(s),distance:s.distance||0,duration:s.duration||60})):simpleSteps(distance,duration); return {id:uid('r'),title,geometry:geom,distance,duration,distanceText:fmtM(distance),durationText:fmtT(duration),mode,emergency,source,facilities,evidence,steps}; }
function emergencyRoute(start,end){ const dist=meters(start,end); return makeRoute([start,end], dist, dist/(MODE[state.mode].kmh*1000/3600), state.mode, '비상 직선 안내', true, 'API 실패 fallback', []); }
function simpleSteps(distance,duration){ return [{instruction:'출발지에서 밝은 큰길 방향으로 이동',distance:distance*.35,duration:duration*.35},{instruction:'안전시설이 많은 구간을 따라 이동',distance:distance*.45,duration:duration*.45},{instruction:'목적지 주변에서 보호자에게 도착 확인',distance:distance*.2,duration:duration*.2}]; }
function stepText(s){ const m=s.maneuver||{}, name=s.name?` ${s.name}`:''; const type={depart:'출발',turn:'회전',arrive:'도착',continue:'직진',merge:'합류',fork:'갈림길',roundabout:'회전교차로'}[m.type]||'이동'; return `${type}${name}`; }
function facilitiesNear(geom){ return state.datasets.facilities.filter(f=>minDistToGeom({lat:f.lat,lon:f.lon},geom) <= (FACILITY_RADIUS[f.type]||100)); }
function countEvidence(fs){ return { cctv:fs.filter(f=>f.type==='cctv').length, light:fs.filter(f=>f.type==='light').length, store:fs.filter(f=>f.type==='store').length, police:fs.filter(f=>f.type==='police').length, risk:fs.filter(f=>f.type==='risk').length }; }
function scoreRoute(r){ let score=55+r.evidence.cctv*5+r.evidence.light*4+r.evidence.store*4+r.evidence.police*7-r.evidence.risk*10; if(!state.datasets.verified)score-=12; if(r.emergency)score-=30; if(state.accuracy&&state.accuracy>80)score-=8; score=Math.max(5,Math.min(95,Math.round(score))); const risk=100-score; const label=score>=78?'낮음':score>=62?'보통':score>=45?'주의':'높음'; return {score,risk,label}; }
function scoreClass(score){ return score>=78?'safe':score>=62?'good':score>=45?'mid':'warn'; }
function minDistToGeom(p,geom){ if(!geom.length)return Infinity; let min=Infinity; for(let i=1;i<geom.length;i++) min=Math.min(min,pointSegDist(p,geom[i-1],geom[i])); return min; }
function pointSegDist(p,a,b){ const x=p.lon,y=p.lat,x1=a.lon,y1=a.lat,x2=b.lon,y2=b.lat,dx=x2-x1,dy=y2-y1; let t=((x-x1)*dx+(y-y1)*dy)/(dx*dx+dy*dy||1); t=Math.max(0,Math.min(1,t)); return meters(p,{lat:y1+t*dy,lon:x1+t*dx}); }
function initMap(){
  const el=$('#map');
  if(!el) return;
  if(typeof L==='undefined'){
    el.innerHTML='<div class="map-error"><b>지도 라이브러리 로드 실패</b><br>인터넷 연결 또는 Leaflet CDN을 확인하세요.</div>';
    return;
  }
  try{
    if(state.map){ try{ state.map.off(); state.map.remove(); }catch(e){ console.warn('[map remove]',e); } state.map=null; }
    if(el._leaflet_id){ try{ delete el._leaflet_id; }catch{ el._leaflet_id=null; } }
    state.map=L.map(el,{zoomControl:true,preferCanvas:true,scrollWheelZoom:true}).setView([DEFAULT_CENTER.lat,DEFAULT_CENTER.lon],13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap',crossOrigin:true}).addTo(state.map);
    setTimeout(()=>{ try{ state.map.invalidateSize(true); drawMap(); }catch(e){ console.warn('[map draw delayed]',e); } },160);
  }catch(e){
    console.error('[map init failed]',e);
    el.innerHTML='<div class="map-error"><b>지도 초기화 오류</b><br>화면을 새로고침하거나 다시 경로 검색을 눌러주세요.</div>';
  }
}
function drawMap(){
  if(!state.map || typeof L==='undefined') return;
  try{
    state.lines.forEach(l=>{try{l.remove();}catch{}});
    state.markers.forEach(m=>{try{m.remove();}catch{}});
    state.lines=[]; state.markers=[];
    const routes=clampRoutes(state.routes);
    routes.forEach(r=>{
      const sc=scoreRoute(r), color=r.emergency?'#ef4444':sc.score>=78?'#22c55e':sc.score>=62?'#38bdf8':sc.score>=45?'#f59e0b':'#ef4444';
      const latlngs=r.geometry.map(p=>[p.lat,p.lon]);
      const line=L.polyline(latlngs,{color,weight:state.selectedRouteId===r.id?8:5,opacity:.92,dashArray:r.emergency?'8 8':null}).addTo(state.map).bindPopup(`${esc(r.title)}<br>${r.emergency?'비상 직선 안내':'위험도 '+sc.risk+'점'}<br>${esc(r.source)}`);
      state.lines.push(line);
    });
    const r=selectedRoute();
    if(r && Array.isArray(r.facilities)){
      r.facilities.filter(f=>isValidCoord(f)).forEach(f=>{
        const icon=L.divIcon({className:'facility-dot',html:FACILITY_ICON[f.type]||'•',iconSize:[24,24]});
        state.markers.push(L.marker([f.lat,f.lon],{icon}).addTo(state.map).bindPopup(`${esc(f.label)}<br>${esc(f.source||'출처 없음')}<br>${f.verified?'공식/검증':'샘플/미검증'}`));
      });
    }
    if(isValidCoord(state.location)){
      state.markers.push(L.circleMarker([state.location.lat,state.location.lon],{radius:9,color:'#38bdf8',fillColor:'#38bdf8',fillOpacity:.8}).addTo(state.map).bindPopup('현재 위치'));
      if(state.accuracy) state.markers.push(L.circle([state.location.lat,state.location.lon],{radius:Math.min(state.accuracy,500),color:'#38bdf8',fillOpacity:.06}).addTo(state.map));
    }
    const all=[];
    routes.forEach(r=>r.geometry.forEach(p=>{ if(isValidCoord(p)) all.push([p.lat,p.lon]); }));
    if(isValidCoord(state.location)) all.push([state.location.lat,state.location.lon]);
    if(all.length>=2) state.map.fitBounds(all,{padding:[34,34],maxZoom:16});
    else if(all.length===1) state.map.setView(all[0],15);
    else state.map.setView([DEFAULT_CENTER.lat,DEFAULT_CENTER.lon],13);
  }catch(e){
    console.error('[draw map failed]',e);
  }
}
function requestLocation(){ if(!navigator.geolocation)return alert('이 브라우저는 위치정보를 지원하지 않습니다.'); if(!state.consent.location){ alert('위치정보 동의가 필요합니다.'); return setState({tab:'privacy'}); } navigator.geolocation.getCurrentPosition(pos=>{ state.location={lat:pos.coords.latitude,lon:pos.coords.longitude,label:'현재 위치'}; state.accuracy=pos.coords.accuracy; state.share.lastUpdate=now(); save(KEYS.share,state.share); render(); }, err=>alert('위치 권한 또는 GPS 오류: '+err.message), {enableHighAccuracy:true,timeout:10000,maximumAge:3000}); }
function startWatch(){ if(!navigator.geolocation)return alert('이 브라우저는 위치정보를 지원하지 않습니다.'); if(!state.consent.location){ alert('위치정보 동의가 필요합니다.'); return setState({tab:'privacy'}); } if(state.watchId) navigator.geolocation.clearWatch(state.watchId); state.watchId=navigator.geolocation.watchPosition(pos=>{ state.location={lat:pos.coords.latitude,lon:pos.coords.longitude,label:'현재 위치'}; state.accuracy=pos.coords.accuracy; state.tracking=true; state.share.lastUpdate=now(); save(KEYS.share,state.share); render(); }, err=>alert('GPS 추적 오류: '+err.message), {enableHighAccuracy:true,timeout:12000,maximumAge:2000}); state.tracking=true; render(); }
function stopWatch(){ if(state.watchId)navigator.geolocation.clearWatch(state.watchId); state.watchId=null; state.tracking=false; if(state.simTimer){clearInterval(state.simTimer);state.simTimer=null;} render(); }
function toggleSim(){ const r=selectedRoute(); if(!r)return alert('먼저 경로를 계산하세요.'); if(state.simTimer){clearInterval(state.simTimer);state.simTimer=null;state.tracking=false;return render();} state.simIndex=0; state.tracking=true; state.simTimer=setInterval(()=>{ state.location=r.geometry[state.simIndex%r.geometry.length]; state.accuracy=18+Math.random()*22; state.share.lastUpdate=now(); save(KEYS.share,state.share); state.simIndex++; if(state.tab==='route' && state.map){ drawMap(); } else { render(); } if(state.simIndex>r.geometry.length+3)toggleSim(); },1200); render(); }
function deviation(){ const r=selectedRoute(); if(!r||!state.location)return null; return minDistToGeom(state.location,r.geometry); }
function beginTrip(){ const r=selectedRoute(); if(!r||r.emergency)return; if(!state.consent.location){ alert('위치정보 동의가 필요합니다.'); return setState({tab:'privacy'}); } state.history.unshift({id:uid('h'),title:r.title,status:'귀가 시작',time:now(),createdAt:Date.now(),distance:r.distanceText,duration:r.durationText,risk:scoreRoute(r).risk,destination:state.destText}); save(KEYS.history,state.history); state.share.lastUpdate=now(); save(KEYS.share,state.share); alert('귀가 기록이 생성되었습니다. 추적 시작을 권장합니다.'); render(); }
function makeShareLink(create){ if(create||!state.share.token){ state.share.token=uid('share'); state.share.expiresAt=Date.now()+1000*60*60*3; state.share.revoked=false; save(KEYS.share,state.share); } return location.origin+location.pathname+'?guardian='+encodeURIComponent(state.share.token); }
function toggleShare(on){ if(on){ if(!state.consent.location||!state.consent.guardian){ alert('위치정보와 보호자 공유 동의가 필요합니다.'); return setState({tab:'privacy'}); } if(!state.contacts.some(c=>c.consent&&c.verified)){ alert('검증된 보호자가 필요합니다. 보호자 동의와 본인 확인을 체크하세요.'); return render(); } makeShareLink(true); state.share.enabled=true; state.share.lastUpdate=now(); state.share.serverConnected=false; } else state.share.enabled=false; save(KEYS.share,state.share); render(); }
function sosMessage(){ const loc=state.location?maskLocation(state.location):'위치 미확인'; const r=selectedRoute(); return `[긴급] 도움이 필요합니다. 현재 위치: ${loc}. 선택 경로: ${r?r.title:'없음'}. 시간: ${now()}. 실제 상황이면 112 신고가 우선입니다.`; }
function maskLocation(loc){ return state.settings.savePreciseLocation ? `${loc.lat.toFixed(5)}, ${loc.lon.toFixed(5)}` : `${loc.lat.toFixed(3)}, ${loc.lon.toFixed(3)} 근방`; }
function setupHold(){ const btn=$('#sosHold'); let start=()=>{ if(state.holdTimer)return; state.hold=0; state.holdTimer=setInterval(()=>{ state.hold+=4; btn.style.setProperty('--p',state.hold+'%'); const small=btn.querySelector('small'); if(small) small.textContent=Math.round(state.hold)+'%'; if(state.hold>=100){ clearInterval(state.holdTimer); state.holdTimer=null; triggerSOS('긴급 SOS'); } },120); }, end=()=>{ if(state.holdTimer){ clearInterval(state.holdTimer); state.holdTimer=null; state.hold=0; render(); } }; btn.onmousedown=start; btn.ontouchstart=e=>{e.preventDefault();start();}; btn.onmouseup=end; btn.onmouseleave=end; btn.ontouchend=end; btn.onkeydown=e=>{ if(e.key===' '||e.key==='Enter')start();}; btn.onkeyup=end; }
function triggerSOS(type){ state.incidents.unshift({id:uid('sos'),type,time:now(),createdAt:Date.now(),message:sosMessage()}); save(KEYS.incidents,state.incidents); state.share.lastUpdate=now(); save(KEYS.share,state.share); alert(type+' 로그가 생성되었습니다. 실제 상황이면 112에 전화하세요.'); setState({tab:'sos',hold:0}); }
function saveConsent(){ state.consent={location:$('#consLoc').checked,guardian:$('#consGuard').checked,retention:$('#consRet').checked,external:$('#consExt').checked,updatedAt:now()}; save(KEYS.consent,state.consent); alert('동의를 저장했습니다.'); render(); }
function cleanupRetention(){ if(!state.consent?.retention)return; const limit=Date.now()-Number(state.settings.retentionDays||30)*86400000; state.history=state.history.filter(x=>(x.createdAt||Date.now())>=limit); state.incidents=state.incidents.filter(x=>(x.createdAt||Date.now())>=limit); save(KEYS.history,state.history); save(KEYS.incidents,state.incidents); }
function exportData(){ const data={consent:state.consent,settings:state.settings,contacts:state.contacts.map(c=>({...c,phone:c.phone.replace(/\d(?=\d{4})/g,'*')})),history:state.history,incidents:state.incidents,share:{...state.share,token:state.share.token?'masked':null},datasets:{source:state.datasets.source,verified:state.datasets.verified,count:state.datasets.facilities.length}}; const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='trust_guard_export.json'; a.click(); URL.revokeObjectURL(a.href); }
function deleteAll(){ if(!confirm('연락처, 기록, 동의, 공유 토큰, 가져온 데이터를 모두 삭제할까요?'))return; Object.values(KEYS).forEach(k=>localStorage.removeItem(k)); init(); }
function importDataset(e){ const file=e.target.files?.[0]; if(!file)return; const reader=new FileReader(); reader.onload=()=>{ try{ const data=JSON.parse(reader.result); if(!Array.isArray(data))throw new Error('배열 형태가 아닙니다.'); const clean=data.filter(x=>x&&['cctv','light','store','police','risk'].includes(x.type)&&Number.isFinite(+x.lat)&&Number.isFinite(+x.lon)&&+x.lat>=33&&+x.lat<=39&&+x.lon>=124&&+x.lon<=132).slice(0,2000).map((x,i)=>({id:x.id||'import-'+i,type:x.type,label:x.label||x.type,lat:+x.lat,lon:+x.lon,verified:false,source:x.source||'사용자 가져오기'})); if(!clean.length)throw new Error('유효한 한국 좌표 시설 데이터가 없습니다.'); state.datasets={facilities:clean,source:'사용자 JSON 가져오기 · 공식 검증 필요',importedAt:now(),verified:false,mode:'user'}; save(KEYS.datasets,state.datasets); alert('데이터를 가져왔습니다. 공식 검증 전까지 미검증 데이터로 처리합니다.'); render(); }catch(err){ alert('가져오기 실패: '+err.message); } }; reader.readAsText(file); }
function askChat(text){ state.chat.push({role:'me',text}); const t=text.toLowerCase(); let reply='현재 버전은 규칙 기반 안내만 제공합니다. 실제 위급 상황이면 112 신고, 밝은 장소 이동, 보호자 연락을 우선하세요.'; if(/위험|무서|따라|스토킹|쫓/.test(t)) reply='지금 위험하다고 느끼면 앱 조작보다 112 전화와 편의점·가게·지구대처럼 밝고 사람이 있는 곳으로 이동하는 게 우선입니다. SOS 화면에서 문구 복사와 112 전화를 바로 사용할 수 있습니다.'; else if(/공유|보호자/.test(t)) reply='보호자 공유는 위치 동의와 보호자 본인 확인이 있어야 켤 수 있습니다. 현재 PWA 파일은 서버 미연결이라 실제 실시간 공유는 서버 구축 후 가능합니다.'; else if(/건양|검색/.test(t)) reply='경로 검색 탭에서 목적지에 “건양대”를 입력하면 건양대학교 메디컬캠퍼스, 논산창의융합캠퍼스, 건양대학교병원 등이 큰 카드로 나타납니다.'; else if(/개인|보안|데이터/.test(t)) reply='정밀 위치 저장은 기본 비활성입니다. 데이터 내보내기, 보관기간 자동정리, 전체 삭제 기능이 있습니다.'; state.chat.push({role:'ai',text:reply}); render(); }
function copyText(text,msg){ navigator.clipboard?.writeText(text).then(()=>alert(msg)).catch(()=>prompt('복사하세요:',text)); }
function registerPWA(){ if('serviceWorker' in navigator){ navigator.serviceWorker.register('./service-worker.js').catch(()=>{}); } window.addEventListener('beforeinstallprompt', e=>{ e.preventDefault(); state.deferredPrompt=e; }); }
function installApp(){ if(state.deferredPrompt){ state.deferredPrompt.prompt(); state.deferredPrompt.userChoice.finally(()=>{state.deferredPrompt=null;}); } else alert('설치 버튼이 보이지 않으면 브라우저 메뉴에서 “앱 설치” 또는 “홈 화면에 추가”를 선택하세요. iPhone은 Safari 공유 버튼에서 홈 화면에 추가를 눌러야 합니다.'); }
function isStandalone(){ return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true; }
window.addEventListener('load', init);
